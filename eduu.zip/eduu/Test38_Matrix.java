//package eduu;
//import java.util.Random;
//public class Test38_Matrix {
//
//	public static void main(String[] args) {
//		Random rand = new Random();
//		
//		int A[][] = new int[3][4];//난수
//		int B[][] = new int[4][5];//난수
//		int C[][] = new int[3][5];//
//		int D[][] = new int[3][4];//난수
//		int E[][] = new int[3][4];//난수
//		int F[][] = new int[4][3];//난수
//		
//		for (int i= 0; i<3 ; i++ ) 
//			for(int j=0; j<4 ; j++ ) 
//				A[i][j] = rand.nextInt(20);	
//		//E[][] = A[][] + D[][]
//		
//		for (int i= 0; i<4 ; i++ ) 
//			for(int j=0; j<5 ; j++ )
//				B[i][j] = rand.nextInt(20);
//		
//		for (int i= 0; i<3 ; i++ ) 
//			for(int j=0; j<4 ; j++ )
//				D[i][j] = rand.nextInt(20);
//		
//	
//		
//		E[3][4] = rand.nextInt(20);
//		F[4][3] = rand.nextInt(20);
//		
//		int sum = 0;
//		
//		//C = A * B  행렬곱하기
//		//E = A + D  행렬더하기
//		//F = A의 전치행렬
//	
//	
//}
//
//}