package eduu;

public class test35 {

	public static void main(String[] args) {
		int[] arr = {10,20,30,40,50};
		
		String []st = {"apple" , "banana" , "pench" };
		int[]arrr = {1,2,3,4,5};
		int j; int sum = 0;
		for ( int i =0; i<3 ; i++) {
			System.out.println(arr[i]);
			sum += i;}
		int i = 20;
		for(String stx:st) //배열원소 전부 출력+인덱스 사용 필요하지 않을때
		System.out.println(stx);
		}
		
	}


