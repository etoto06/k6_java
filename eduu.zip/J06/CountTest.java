package J06;

class Count{
	public static int totalCount;
	int count;
}

public class CountTest{
	public static void main(String[] args) {
		Count.totalCount++;
		System.out.println("실행시작");
		/*Count c1 = new Count();
		Count c2 = new Count();
		Count c3 = new Count();*/
	}
}
