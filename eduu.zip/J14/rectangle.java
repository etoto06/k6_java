package J14;

public class rectangle {

}
