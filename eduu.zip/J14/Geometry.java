package J14;

import java.util.function.Function;

interface cincle{
	int radius();
}

interface rectangle{
	int width();
	int height();
}

interface triangle{
	int height();
	int width();
}

public class Geometry {
	
	public static void main(String[] args) {
		Geometry g = new Geometry();
		
		Geometry calc = () -> {
			
			
	};
	
}
}
//              Geometry
//    cincle 			rectangle			triangle	
    					
//    int radius		int width			int height
//  					int height			int width