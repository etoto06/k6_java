package com.ruby.java05;

class Armor {
	private String name="홍길동";
	private int height=180;
	private int weight=100;
	String color = "red";
	
	void takeoff() {
		System.out.println("Take Off");
	}
	private void land() {
		System.out.println("Land");
	}
	private void shootLaser() {
		System.out.println("Shoot");
	}
}

//public class ArmorTest{
//	public static void main(String[] args) {
//		Armor armor = new Armor();
//		
////		armor"홍길동";
////		}
////}

//ctrl+shift+o = 필요한 패키지 불러옴