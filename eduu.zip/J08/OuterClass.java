package J08;

public class OuterClass {
	
	class InstanceClass{
		int a;
		void method2() {
			System.out.println("instance Class : " +a );
		}
	}
}
