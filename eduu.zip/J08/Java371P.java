package J08;

public class Java371P {
 static class statticClass{
	 int b;
	 static int c;
	 void method3() {
		 System.err.println("Static ");}
	 }
}
