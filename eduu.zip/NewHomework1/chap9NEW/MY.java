package NewHomework1.chap9NEW;

public class MY {	
	public LinkedList() {
		head = crnt =null;
	}

}
