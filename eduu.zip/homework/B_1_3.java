package homework;

import java.util.Scanner;

public class B_1_3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner
	}
}
