package homework;

import java.util.Scanner;

public class Lines {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("x좌표들을 입력해주세요");
		int x1,x2,x3,x4 = sc.nextInt();
		System.out.println("y좌표들을 입력해주세요");
		i

		
	}

}
