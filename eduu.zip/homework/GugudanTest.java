package homework;

import java.util.Scanner;

public class GugudanTest {
	
	public static void main(String[] args) {
		
		Gugudan ggd = new Gugudan();
		
		for(int k=1;k<10;k++) {
			//for()
		ggd.print(k);
		System.out.println("\n");
		System.out.println("-".repeat(15));
		}
		System.out.print("end");
	}

}
