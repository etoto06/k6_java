package J07;

import java.security.PublicKey;

public interface WorkFIle {
	public void fileUpload();
	public void fileDownload();

}
