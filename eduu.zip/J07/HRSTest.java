/*package J07;

public class HRSTest {
	
	abstract class Employee{
		String name;
		int salary;
		
		public abstract void calcSalary();
	}
	
	class Salesman extends Employee{
		public void calcSlary() {
			System.out.println("Salesman 급여 = 기본급 + 판매수당");
		}
	}
 
	class Consultant extends Employee{
		public void calcSalary() {
			System.out.println("급여 = 기본급+컨설팅 특별수탕");
		}
	}
	
	class Manager extends Employee{
		public void calcSalry() {
			System.out.println("급여= 기본급 + 팀 성과수당");
		}
	}
	
	class Director extends Manger{

	}
	
	public class HRSTest{
		public static void main(String[] args) {
			Salesman s = new Salesman();
			Consultant c = new consultant();
			Manger m = new Manger();
			

			s.calcSalary();
			c.calcSalary();
			m.calcSalary();
			
		}
	}
}
*/