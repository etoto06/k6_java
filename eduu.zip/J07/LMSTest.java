/*package J07;

public class LMSTest {
	public static void main(String[] args) {
		
		Employee e = new Employee();
		Professor p = new Professor();
		Student s = new Student();
		
		e.setName("오정임");
		e.setAge(47);
		e.setDept("입학척");
		
		p.setName("김하능");
		p.setAge(47);
		p.setSubject("입학척");
		
		s.setName("오정임");
		s.setAge(47);
		s.setMajor("입학척");
		
		System.out.println(e.toString());
		System.out.println(p.toString());
		System.out.println(s.toString());
	}
}

/* void work() {
메서드의 바디
}

abstract void work (); 바디가 없는 매서드, 추상메서드
abstract 꼭 붙여야함 , 자매품 추상클래스 

쓰는이유
앱슬틀랙이 붙으면 객체를 만들수가 없음(추상클래스)

항상 추상클래스는 자식
           
*
*/