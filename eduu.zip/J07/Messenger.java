package J07;

public interface Messenger {

	String MIN_SIZE = null;
	String MAX_SIZE = null;

}
